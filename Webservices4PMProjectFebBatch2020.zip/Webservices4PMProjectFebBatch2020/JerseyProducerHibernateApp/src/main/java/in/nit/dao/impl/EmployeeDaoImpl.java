package in.nit.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import in.nit.dao.IEmployeeDao;
import in.nit.model.Employee;
import in.nit.util.HibernateUtil;

public class EmployeeDaoImpl 
	implements IEmployeeDao
{

	@SuppressWarnings("unchecked")
	@Override	
	public List<Employee> getAllEmployees() {
		Session ses=HibernateUtil.getSf().openSession();
		List<Employee> list=null;
		try (ses){
			
			list=ses
			.createQuery("from in.nit.model.Employee e")
			.list();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	
	
	@Override
	public Integer saveEmployee(Employee e) {
		Session ses=HibernateUtil.getSf().openSession();
		Transaction tx=null;
		Integer id=null;
		try(ses) {
			tx=ses.beginTransaction();
			id=(Integer)ses.save(e);
			//ses.getTransaction().commit();
			tx.commit();
		} catch (Exception ex) {
			//ses.getTransaction().rollback();
			tx.rollback();
			ex.printStackTrace();
		}
		
		return id;
	}
	
	@Override
	public void deleteEmployee(Integer id) {
		Session ses=HibernateUtil.getSf().openSession();
		Transaction tx=null;
		try (ses){
			tx=ses.beginTransaction();
			/*delete method input is
			 * Object having PK
			 * Employee(id)
			 */
			Employee emp=new Employee();
			emp.setEmpId(id);
			ses.delete(emp);
			tx.commit();
		} catch (Exception e) {
			tx.rollback();
			e.printStackTrace();
		}
	}
	
	
}







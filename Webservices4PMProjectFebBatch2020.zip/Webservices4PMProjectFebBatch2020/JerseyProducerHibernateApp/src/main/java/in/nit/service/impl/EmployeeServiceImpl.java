package in.nit.service.impl;

import java.util.Collections;
import java.util.List;

import javax.inject.Inject;

import in.nit.dao.IEmployeeDao;
import in.nit.model.Employee;
import in.nit.service.IEmployeeService;

public class EmployeeServiceImpl 
	implements IEmployeeService
{

	@Inject
	private IEmployeeDao dao;
	
	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> emps=dao.getAllEmployees();
		Collections.sort(emps);
		return emps;
	}

	@Override
	public Integer saveEmployee(Employee e) {
		return dao.saveEmployee(e);
	}
	
	@Override
	public void deleteEmployee(Integer id) {
		dao.deleteEmployee(id);
	}
}








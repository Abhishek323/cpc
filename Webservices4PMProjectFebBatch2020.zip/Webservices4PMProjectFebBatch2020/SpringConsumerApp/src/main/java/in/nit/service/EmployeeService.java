package in.nit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.nit.consumer.EmployeeRestConsumer;
import in.nit.model.Employee;

@Service
public class EmployeeService {
	@Autowired 
	private EmployeeRestConsumer consumer;
	
	public String saveEmployee(Employee e) {
		//logics,calculation
		return consumer.saveEmployee(e);
	}
	
	public List<Employee> getAllEmployees(){
		return consumer.getAllEmployees();
	}
	
	public String deleteEmployee(Integer id) {
		return consumer.deleteEmployee(id);
	}
	
	
	
	
	
}



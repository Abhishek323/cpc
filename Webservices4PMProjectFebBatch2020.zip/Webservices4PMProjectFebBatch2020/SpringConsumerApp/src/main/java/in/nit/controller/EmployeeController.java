package in.nit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import in.nit.model.Employee;
import in.nit.service.EmployeeService;

@Controller  //obj + HTTP
public class EmployeeController {
	@Autowired
	private EmployeeService service;
	
	//to show register page
	@RequestMapping("/reg")
	public String showRegPage() {
		return "EmpReg";
	}
	// to read form data
	@RequestMapping(value = "/save",
			method = RequestMethod.POST)
	public String saveEmp(
			@ModelAttribute Employee employee,
			Model model
			)
	{
		String msg=service.saveEmployee(employee);
		model.addAttribute("msg", msg);
		return "EmpReg";
	}
    //display all rows at UI
	@RequestMapping("/all")
	public String fetchAllEmps(Model model) {
		List<Employee> list=service.getAllEmployees();
		model.addAttribute("list", list);
		return "EmpData";
	}
	//delete employee based on ID
	@RequestMapping("/delete")
	public String deleteEmp(
			@RequestParam("id")Integer id,
			Model model) 
	{
		String msg=service.deleteEmployee(id);
		model.addAttribute("message", msg);
		return "EmpResult";
	}
	
	
}





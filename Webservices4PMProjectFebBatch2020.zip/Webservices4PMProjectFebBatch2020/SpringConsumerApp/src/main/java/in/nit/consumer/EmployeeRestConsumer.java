package in.nit.consumer;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import in.nit.model.Employee;

@Component
public class EmployeeRestConsumer {

	public String saveEmployee(Employee e) {
		String URL="http://localhost:2020/JerseyProducerHibernateApp/rest/employee";
		RestTemplate rt=new RestTemplate();
		String msg=rt.postForObject(URL, e, String.class);
		return msg;
	}
	
	public List<Employee> getAllEmployees(){
		String URL="http://localhost:2020/JerseyProducerHibernateApp/rest/employee";
		RestTemplate rt=new RestTemplate();
		Employee[] arr=rt.getForObject(URL, Employee[].class);
		return Arrays.asList(arr);
	}
	
	public String deleteEmployee(Integer id) {
		String URL="http://localhost:2020/JerseyProducerHibernateApp/rest/employee?id="+id;
		RestTemplate rt=new  RestTemplate();
		ResponseEntity<String> re=rt.exchange(URL, HttpMethod.DELETE, null,String.class);
		
		return id+"-"+re.getBody();
	}
	
	
	
	
}



